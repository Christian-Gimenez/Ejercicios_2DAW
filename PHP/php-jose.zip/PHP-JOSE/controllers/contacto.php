<?php

$seccion="Contacto";
require "views/contacto.view.php";
