<?php

$seccion="Información";

require "views/info.view.php";
