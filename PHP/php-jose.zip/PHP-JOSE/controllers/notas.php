<?php

$seccion="Notas";
require "views/notas.view.php";
