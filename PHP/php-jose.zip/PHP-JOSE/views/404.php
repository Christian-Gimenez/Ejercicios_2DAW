<?php
require "partials/cabecera.php";
require "partials/nav.php";
?>

<div class="bg-body-tertiary p-5 rounded">
  <h1>Ups... Error 404</h1>
  <p>¡Página no encontrada!</p>

  <p><a href="/">Volver a la página de inicio</a></p>
</div>
<?php
require "partials/pie.php";
