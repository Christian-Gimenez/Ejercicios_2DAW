<?php
require "partials/cabecera.php";
require "partials/nav.php";
require "partials/hero.php";
require "partials/contenido.php";
require "partials/pie.php";