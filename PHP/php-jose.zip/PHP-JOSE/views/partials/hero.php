<header class="bg-info p-2 mt-2 rounded">
    <h1 class="h2"><?= $seccion ?></h1>
</header>