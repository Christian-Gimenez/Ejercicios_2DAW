<footer class="bg-body-secondary p-2 fixed-bottom"><h3>Footer</h3></footer>
</body>

</html>